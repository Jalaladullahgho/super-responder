(function() {
    var isLoading = false;
    var isLoaded = false;
    
    function loadScrollingText() {
        if (isLoading || isLoaded) return;
        isLoading = true;
        
        var url = sp + 'client/gettxt' + pp + '?network_id=' + nd + '&type=text&read_pass=' + rs;
        
        CacheManager.fetchWithCache(url, 'cached_text')
            .then(function(data) {
                if (data && !data.error && data.text) {
                    var els = document.querySelectorAll('#scroll-text-content');
                    els.forEach(function(el){ el.innerText = data.text; });
                    isLoaded = true;
                }
            })
            .catch(function() {})
            .finally(function() {
                isLoading = false;
            });
    }
    
    if (typeof CacheManager !== 'undefined') {
        loadScrollingText();
    } else {
        setTimeout(loadScrollingText, 50);
    }
    
    window.addEventListener('cacheUpdated', function(e) {
        if (e.detail.key === 'cached_text') {
            var data = e.detail.data;
            if (data && !data.error && data.text) {
                var els = document.querySelectorAll('#scroll-text-content');
                els.forEach(function(el){ el.innerText = data.text; });
            }
        }
    });
})();
