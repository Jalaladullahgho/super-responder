(function() {
    var isLoading = false;
    var isLoaded = false;
    
    function applyColors(colors) {
        if (!colors) return;
        Object.keys(colors).forEach(function(colorKey) {
            var elements = document.querySelectorAll("." + colorKey);
            elements.forEach(function(el) {
                el.style.setProperty('background', colors[colorKey], 'important');
                if (colorKey === "btn_color") {
                    el.style.setProperty('color', '#ffffff', 'important');
                }
            });
            if (colorKey === "bd_color") {
                document.body.style.setProperty('background', colors[colorKey], 'important');
            }
        });
    }
    
    function fetchColors() {
        if (isLoading || isLoaded) return;
        isLoading = true;
        
        var params = new URLSearchParams();
        params.append("action", "get_colors");
        params.append("network_id", nd);
        params.append("read_pass", rs);
        
        var url = sp + 'client/getcolor' + pp;
        
        CacheManager.fetchWithCache(url, 'cached_colors', {
            method: "POST",
            body: params
        })
        .then(function(colors) {
            applyColors(colors);
            isLoaded = true;
        })
        .catch(function() {})
        .finally(function() {
            isLoading = false;
        });
    }
    
    if (typeof CacheManager !== 'undefined') {
        fetchColors();
    } else {
        setTimeout(fetchColors, 50);
    }
    
    window.addEventListener('cacheUpdated', function(e) {
        if (e.detail.key === 'cached_colors') {
            applyColors(e.detail.data);
        }
    });
})();
