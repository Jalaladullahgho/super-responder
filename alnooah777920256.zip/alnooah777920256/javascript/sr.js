// ملف القيم الافتراضية - يعمل حتى بدون conf.js أو اتصال بالسرفر
const sph = `https://hotspot.fntvs.net/`;
const sp = `https://hotspot.fntvs.net/`;

// قيم افتراضية للمتغيرات الأساسية
if(typeof nd==='undefined'){window.nd=0;}
if(typeof rs==='undefined'){window.rs='';}
if(typeof pp==='undefined'){window.pp='.php';}
if(typeof hp==='undefined'){window.hp='https:';}
if(typeof cm==='undefined'){window.cm='.com/';}
if(typeof jt==='undefined'){window.jt='javascript/';}
if(typeof sj==='undefined'){window.sj='.js';}
if(typeof gt==='undefined'){window.gt='';}
if(typeof sh==='undefined'){window.sh='';}
if(typeof cnf==='undefined'){window.cnf='';}
